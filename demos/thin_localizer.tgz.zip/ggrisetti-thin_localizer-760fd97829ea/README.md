thin localizer
lightweight variant to amcl, for teaching purposes

- compile with catkin

- launch the simulator from the test directory
$> rosrun stage_ros stageros dis-B1-2011-09-27.world

- launch the localizer, providing the map image
$> rosrun thin_localizer thin_localizer_node dis-B1-2011-09-27.png

This will open a window showing the state of the localizer

move the robot with a joystick or some other teleoperation means
